{{-- @extends("layouts.app")

@section("content")
    <h1>Contact</h1>
@endsection

@section("page-title", "Contact - Laravel DC Comics") --}}
